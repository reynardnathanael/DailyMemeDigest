package com.reynard.dailymemedigest

object Global {
//    val api="http://10.0.2.2/NMP/DailyMemeDigest/api/"
    val api = "https://ubaya.fun/native/160720034/memes_api/"
    val sharedFile = "com.reynard.dailymemedigest"
}