package com.reynard.dailymemedigest

data class Leaderboards(var name: String, val avatar_img: String, var num_likes: Int)
